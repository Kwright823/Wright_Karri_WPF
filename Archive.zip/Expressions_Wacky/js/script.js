//Karri Wright October 9, 2014 Expressions_Wacky

//How much wood could a woodchuck chuck if a woodchuck could chuck wood?

var wood = prompt("How many pieces of wood do you have?");
var woodChuck = prompt("How many Woodchucks are there with you?");
var couldChuck = prompt("Do you think a Woodchuck could chuck wood?");
console.log(wood);
console.log(woodChuck);
console.log(couldChuck);

var totalWood = wood * woodChuck;
alert(totalWood + " " + "pieces of wood is how much wood a Woodchuck could chuck if a Woodchuck could chuck wood.");
