//Karri Wright October 9, 2014 Expressions_Industry


//I am a stay at home mom at the moment, however, I did recently work at KeyBank as a teller

var checks = [123, 456, 789]; //array of checks
var cash = [91, 82, 73]; //array of cash
var cashBack = 10;

var totalDep = checks[0] + checks[1] + checks[2] +
    cash[0] + cash[1] + cash[2] - cashBack; //totaling up all the arrays
console.log(totalDep);

alert(totalDep);

//I am not sure how to do pop ups with an array
//Is there a way to categorize the popups with a certain index # to put them into an array?

